
1. About
-------------------------

This plugin is designed to be loaded on an AIX LPAR with WPAR's configured.  

Below is a description of each of the AIX WPAR Workload settings that are used:

 Script Name   - the location of the script on the monitoring station that
                 contains the logic for contacting the agent and returning
                 the output in a useful format to the monitoring station
 Port          - port that the up.time agent is listening on (default 9998)
 Password      - password that the up.time agent has setup
                 (on some/older agents)
		 See step 2b below.


The following are metrics gathered by the plugin:

	LPAR Physical Processor Utilization (proc)	
	LPAR Entitled Capacity Utilization (%)	
	WPAR CPU User(%)	
	WPAR CPU System (%)	
	WPAR CPU Waiting on IO (%)	
	WPAR CPU Idle (%)	
	WPAR Physical Processor Utilization (proc)	
	WPAR Physical Processor Utilization (%)	
	WPAR Memory Size (pages)	
	WPAR Memory In Use (pages)	
	WPAR Memory Free(pages)	
	WPAR Paging Space Size (pages)	
	WPAR Paging Space In Use (pages)	
	Response time (ms)


2. Agent Installation
-------------------------

a. Place the wpar-monitor.sh file in the directory /opt/uptime-agent/scripts/
   (create the directory if needed)
b. Create/edit the following password file:
   /opt/uptime-agent/bin/.uptmpasswd
   and add the following line to it:
   <password>   /opt/uptime-agent/scripts/wpar-monitor.sh

