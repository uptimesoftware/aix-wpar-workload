#!/bin/sh

SARBIN=/usr/sbin/sar
TMP_SVMON_FILE="/tmp/wpar_monitor_$$_svmon.tmp"
TMP_SVMON_WPAR_FILE="/tmp/wpar_monitor_$$_svmon_wpar.tmp"
TMP_SAR_WPAR_FILE="/tmp/wpar_monitor_$$_sar_wpar.tmp"
TMP_FILE="/tmp/wpar_monitor_$$_general.tmp"

# Get Memory Utilization Metrics For ALL WPARs
svmon -@ ALL > ${TMP_SVMON_FILE}
if [ "$?" != "0" ]
then
    echo "ERROR: svmon -@ is not supported"
    rm ${TMP_SVMON_FILE}
    exit 1
fi


# Get CPU Utilization Metrics For ALL WPARs
# Has to loop through each WPAR since there's no command to get them all at once
ALL_TMP_SAR_WPAR_FILE=""
lswpar | tail +3 | while read WPAR_LINE
do
    WPAR_STATE=`echo ${WPAR_LINE} | awk '{print $2}'`
    WPAR=`echo ${WPAR_LINE} | awk '{print $1}'`
    if [ "${WPAR_STATE}" = "A" ]
    then
        $SARBIN -@ ${WPAR} 1 2 > ${TMP_SAR_WPAR_FILE}.${WPAR} 
        if [ "$?" != "0" ]
        then
            echo "ERROR: sar -@ is not supported"
            rm ${TMP_SVMON_FILE}
            rm ${TMP_SAR_WPAR_FILE}.${WPAR}
            exit 1
        fi

        ALL_TMP_SAR_WPAR_FILE="${ALL_TMP_SAR_WPAR_FILE} ${TMP_SAR_WPAR_FILE}.${WPAR}"
    fi
done


# Get CPU Utilization for LPAR
$SARBIN 1 2 > ${TMP_SAR_WPAR_FILE}.LPAR
ALL_TMP_SAR_WPAR_FILE="${ALL_TMP_SAR_WPAR_FILE} ${TMP_SAR_WPAR_FILE}.LPAR"
LPAR_PHYSC=`cat ${TMP_SAR_WPAR_FILE}.LPAR |  grep -v Average | egrep -v "^$" | tail -1 | awk '{print $6}'`
LPAR_ENTC=`cat ${TMP_SAR_WPAR_FILE}.LPAR |  grep -v Average | egrep -v "^$" | tail -1 | awk '{print $7}'`
if [ "${LPAR_PHYSC}" = "-" -o "${LPAR_PHYSC}" = "" ]
then
    LPAR_PHYSC=0
fi

if [ "${LPAR_ENTC}" = "-" -o "${LPAR_ENTC}" = "" ]
then
    LPAR_ENTC=0
fi
echo "lparPhysc ${LPAR_PHYSC}"
echo "lparEntc ${LPAR_ENTC}"



lswpar | tail +3 | while read WPAR_LINE
do
    WPAR_STATE=`echo ${WPAR_LINE} | awk '{print $2}'`
    WPAR=`echo ${WPAR_LINE} | awk '{print $1}'`
    if [ "${WPAR_STATE}" = "A" ]
    then
        ####################################
        # Parse for CPU metrics
        ####################################
        CPU_USR=`cat ${TMP_SAR_WPAR_FILE}.${WPAR} | grep -v Average | egrep -v "^$" | tail -1 | awk '{print $2}'`
        CPU_SYS=`cat ${TMP_SAR_WPAR_FILE}.${WPAR} | grep -v Average | egrep -v "^$" | tail -1 | awk '{print $3}'`
        CPU_WIO=`cat ${TMP_SAR_WPAR_FILE}.${WPAR} | grep -v Average | egrep -v "^$" | tail -1 | awk '{print $4}'`
        CPU_IDLE=`cat ${TMP_SAR_WPAR_FILE}.${WPAR} | grep -v Average | egrep -v "^$" | tail -1 | awk '{print $5}'`
        CPU_PHYSC=`cat ${TMP_SAR_WPAR_FILE}.${WPAR} | grep -v Average | egrep -v "^$" | tail -1 | awk '{print $6}'`
        CPU_RESC=`cat ${TMP_SAR_WPAR_FILE}.${WPAR} | grep -v Average | egrep -v "^$" | tail -1 | awk '{print $7}'`

        if [ "${CPU_USR}" = "-" -o "${CPU_USR}" = "" ]
        then
            CPU_USR=0
        fi

        if [ "${CPU_SYS}" = "-" -o "${CPU_SYS}" = "" ]
        then
            CPU_SYS=0
        fi

        if [ "${CPU_WIO}" = "-" -o "${CPU_WIO}" = "" ]
        then
            CPU_WIO=0
        fi

        if [ "${CPU_IDLE}" = "-" -o "${CPU_IDLE}" = "" ]
        then
            CPU_IDLE=0
        fi

        if [ "${CPU_PHYSC}" = "-" -o "${CPU_PHYSC}" = "" ]
        then
            CPU_PHYSC=0
        fi

        if [ "${CPU_RESC}" = "-" -o "${CPU_RESC}" = "" ]
        then
            CPU_RESC=0
        fi

        echo "${WPAR}.cpuUser ${CPU_USR}"
        echo "${WPAR}.cpuSys ${CPU_SYS}"
        echo "${WPAR}.cpuWio ${CPU_WIO}"
        echo "${WPAR}.cpuIdle ${CPU_IDLE}"
        echo "${WPAR}.cpuPhysc ${CPU_PHYSC}"
        echo "${WPAR}.cpuResc ${CPU_RESC}"

        ####################################
        # Parse for memory metrics
        ####################################
        START_LINE=`grep -n \#\#\#.*${WPAR} ${TMP_SVMON_FILE} | cut -f1 -d:`
        START_LINE=`expr ${START_LINE} + 2`
        sed -n "${START_LINE},\$p" ${TMP_SVMON_FILE} > ${TMP_SVMON_WPAR_FILE}
        # Check if there are other WPARs in this file
        # If so, chop other WPARs
        if [ "`grep \#\#\#\# ${TMP_SVMON_WPAR_FILE}`" != "" ]
        then
            END_LINE=`grep -n \#\#\#\# ${TMP_SVMON_WPAR_FILE} | head -1 | cut -d: -f1`
            END_LINE=`expr ${END_LINE} - 1`
            sed -n "1,${END_LINE}p" ${TMP_SVMON_WPAR_FILE} > ${TMP_FILE}
            mv ${TMP_FILE} ${TMP_SVMON_WPAR_FILE}
        fi

        MEM_SIZE=`grep memory ${TMP_SVMON_WPAR_FILE} | awk '{print $2}'`
        MEM_INUSE=`grep memory ${TMP_SVMON_WPAR_FILE} | awk '{print $3}'`
        MEM_FREE=`grep memory ${TMP_SVMON_WPAR_FILE} | awk '{print $4}'`

        PG_SIZE=`grep "pg space" ${TMP_SVMON_WPAR_FILE} | awk '{print $3}'`
        PG_INUSE=`grep "pg space" ${TMP_SVMON_WPAR_FILE} | awk '{print $4}'`

        if [ "${MEM_SIZE}" = "-" ]
        then
            MEM_SIZE=0
        fi
 
        if [ "${MEM_INUSE}" = "-" ]
        then
            MEM_INUSE=0
        fi

        if [ "${MEM_FREE}" = "-" ]
        then
            MEM_FREE=0
        fi

        if [ "${PG_SIZE}" = "-" ]
        then
            PG_SIZE=0
        fi

        if [ "${PG_INUSE}" = "-" ]
        then
            PG_INUSE=0
        fi

        echo "${WPAR}.memSize ${MEM_SIZE}"
        echo "${WPAR}.memInuse ${MEM_INUSE}"
        echo "${WPAR}.memFree ${MEM_FREE}"
        echo "${WPAR}.pgSize ${PG_SIZE}"
        echo "${WPAR}.pgInuse ${PG_INUSE}"
    else
        echo "${WPAR}.cpuUser 0"
        echo "${WPAR}.cpuSys 0"
        echo "${WPAR}.cpuWio 0"
        echo "${WPAR}.cpuIdle 0"
        echo "${WPAR}.cpuPhysc 0"
        echo "${WPAR}.cpuResc 0"
        echo "${WPAR}.memSize 0"
        echo "${WPAR}.memInuse 0"
        echo "${WPAR}.memFree 0"
        echo "${WPAR}.pgSize 0"
        echo "${WPAR}.pgInuse 0"
    fi
done
    

for FILE in ${TMP_SVMON_FILE} ${TMP_SVMON_WPAR_FILE} ${TMP_SAR_WPAR_FILE} ${TMP_FILE} ${ALL_TMP_SAR_WPAR_FILE} ${TMP_SAR_WPAR_FILE}.LPAR
do
    rm ${FILE} 2> /dev/null
done
